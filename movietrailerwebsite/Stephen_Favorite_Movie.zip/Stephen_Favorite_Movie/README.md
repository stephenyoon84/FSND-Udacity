# Movie Trailer Website Project  03/13/2017
============================================

* python

* html - fresh_tomatoes.html is the file to see the result in the web browser

* Python - media.py
  - Clarify Movie() class
    - init : contain information(movie_title, movie_storyline, poster_image, trailer_youtube)
    - show_trailer : instance method to show trailer

* Python - fresh_tomatoes.py
  - A Python module provided by course

* Python - entertainment_center.py
  - list of the information about my favorite movies
  - contents : title, storyline, image, youtube trailer

* HTML - fresh_tomatoes.html
  - HTML which is provided by course
