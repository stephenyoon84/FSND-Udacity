-- Table definitions for the tournament project.
--
-- Put your SQL 'create table' statements in this file; also 'create view'
-- statements if you choose to use it.
--
-- You can write comments in this file by starting them with two dashes, like
-- these lines here.

create table players (name text, player_id serial primary key);

create table matches (round_num serial primary key, winner int references players(player_id) not null,
  loser int references players(player_id));

create view standings as
  select players.player_id, players.name,
  (select count(matches.winner) from matches where players.player_id = matches.winner) as total_wins,
  (select count(matches.round_num) from matches where players.player_id = matches.winner or players.player_id = matches.loser)
  as total_matches from players order by total_wins desc, total_matches desc;


-- create table players (player_name text, id serial primary key);
--
-- create table contests (round serial primary key, winner int references players(id),
--                       loser int references players(id));
-- create VIEW number_of_wins AS
--     select players.id, players.player_name,
--            count(contests.winner) AS wins
--     FROM players, contests where players.id = contests.winner
--     group by players.id;
-- create VIEW matches_played AS
--     SELECT players.player_name,  players.id, count(*) AS contests
--     FROM players left join contests on players.id = contests.winner
--         OR players.id = contests.loser
--     group by players.id;
--
-- create VIEW standings AS
--     SELECT * FROM matches_played left join number_of_wins
--         on matches_played.id = contests.winner
--     order by wins desc;
-- CREATE TABLE players (player_id SERIAL primary key, name TEXT);
--
-- CREATE TABLE matches (player_id SERIAL primary key, winner INTEGER, loser INTEGER);
--
-- CREATE TABLE standings (player_id SERIAL primary key, wins INTEGER, loses INTEGER, matches INTEGER);
--
-- CREATE TABLE pairings (player_id SERIAL primary key, player1 TEXT, player2 TEXT);
